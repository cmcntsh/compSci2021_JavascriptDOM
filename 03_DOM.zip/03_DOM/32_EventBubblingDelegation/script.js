// Event bubbling - events on child elements bubble up to parent elements
// Event delegation - listener on parent element targets a child element

// event bubbling

document.querySelector('.card-title').addEventListener('click', function(){
    console.log('card title');
});

document.querySelector('.card-content').addEventListener('click', function(){
    console.log('card content');
});

document.querySelector('.card').addEventListener('click', function(){
    console.log('card');
});

document.querySelector('.col').addEventListener('click', function(){
    console.log('col');
});

// event delegation - put listener on parent then go down

// const delItem = document.querySelector('.delete-item'); // putting listener on delete-item class only works for first one

// deleteItem.addEventListener('click', deleteItem);

document.body.addEventListener('click', deleteItem);

function deleteItem(e){
    //console.log('delete item');
    console.log(e.target);
    // if(e.target.className === 'fa fa-remove'){
    //     console.log('delete item');
    // }

    // if(e.target.parentElement.className === 'delete-item secondary-content'){
    //     console.log('delete item');
    // }

    if(e.target.parentElement.classList.contains('delete-item')){
        console.log('delete item');
        e.target.parentElement.parentElement.remove();
    }
}

