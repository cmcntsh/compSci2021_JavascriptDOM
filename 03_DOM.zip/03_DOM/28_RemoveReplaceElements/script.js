// replace elements

// create element
const newHeading = document.createElement('H2');
// add id
newHeading.id = 'task-title';
// new text node
newHeading.appendChild(document.createTextNode('Task List'));

// get old heading
const oldHeading = document.getElementById('task-title');
//parent
const cardAction = document.querySelector('.card-action');

// replace
cardAction.replaceChild(newHeading, oldHeading);


console.log(newHeading)

// remove element
const lis = document.querySelectorAll('li');
const list = document.querySelector('ul');

// remove list item
lis[0].remove();

// remove child element
list.removeChild(lis[3]);

// class and attributes
const firstLi = document.querySelector('li:first-child');
const link = irstLi.children[0]
console.log(firstLi.children[0]);

let val;

// classes
val = link.className;
val = link.classList;
val = link.classList[0];
link.classList.add('test');
link.classList.remove('test');
val = link;

// attributes
val = link.getAttribute('href');
val = link.setAttribute('href', 'http://google.com');

val = link.hasAttribute('href'); // test to see if attribute present

link.setAttribute('title', 'Google');
val = link

link.removeAttribute('title');