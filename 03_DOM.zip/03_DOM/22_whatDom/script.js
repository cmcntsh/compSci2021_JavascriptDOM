/*
DOM = Document Object Model
- tree of nodes/elements created by the browser
- Javascript can be used to read/write/manipulate the DOM
- object oriented representation
- can type "document" in console and see object tree
*/