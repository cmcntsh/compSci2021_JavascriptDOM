let val;

const list = document.querySelector('ul.collection');
const listItem = document.querySelector('li.collection-item:first-child');

val = listItem;
val = list;

// get child nodes, gives us all different types of nodes - not just element
val = list.childNodes; // will have text which is line breaks
val = list.childNodes[0];
val = list.childNodes[0].nodeName;
val = list.childNodes[0].nodeType;

// Types of nodes
// 1 - Element
// 2 - Attribute (depricated)
// 3 - Text node
// 8 - Comment
// 9 - Document itself
// 10 - Doctype

// get children element node, will give us just the elements and not other node types
val = list.children;
val = list.children[0];
val = list.children[0].textContent = 'Hello';
// children of children
list.children[3].children[0].id = 'test-link';
val = children[3].children;

// first child
val = list.firstChild; // includes all node types
val = list.firstElementChild; // includes just the element nodes

// last child
val = list.lastChild; // includes all node types
val = list.lastElementChild; // includes just the element nodes

// count
val = list.childElementCount;


// get parent node, same things with child but with parent
val = listItem.parentNode;
val = listItem.parentElement;
val = listItem.parentElement.parentElement;


// get next sibling
val = listItem.nextSibling; // works with all node types
val = listItem.nextElementSibling; // works with just element nodes

// get previous sibling
val = listItem.previousSibling; // works with all node types
val = listItem.previousElementSibling; // works with just element nodes

console.log(val);