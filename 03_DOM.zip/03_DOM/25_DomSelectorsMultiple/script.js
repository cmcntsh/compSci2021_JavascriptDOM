// select collection of elements 
// return either an html collection or a node list
// not iterable like arrays unless you change them into array

// document.getElementsByClassName

const items = document.getElementsByClassName('collection-item');

console.log(items);
console.log(items[0]);
items[0].style.color = 'red';
items[3].textContent = 'Hello';

const listItems = document.querySelector('ul').getElementsByClassName('collection-item');

console.log(listItems);

// document.getElementByTagName
//const lis = document.getElementsByTagName('li'); // This gives html collection with all li
let lis = document.getElementsByTagName('li'); // use let when converting to array later

console.log(lis);
console.log(lis[0]);
lis[0].style.color = 'red';
lis[3].textContent = 'Hello';

lis.reverse(); // won't work because it is an array method

lis = Array.from(lis) // convert html list to array

lis.reverse(); // will work because it is an array method

lis.forEach(function(li, index){
    console.log(li.className)
    li.textContent = `${index}: Hello`;
});

console.log(lis);


// returns a no list
// document.querySelectorAll

const items = document.querySelectorAll('ul.collection li.collection-item'); // This returns a node list.

lis.forEach(function(item, index){ // This works because it's a node list.
    console.log(item.className)
    item.textContent = `${index}: Hello`;
});

const liOdd = document.querySelectorAll('li:nth-child(odd)');
const liOdd = document.querySelectorAll('li:nth-child(even)');

liOdd.forEach(function(li, index){ // Changes the odd list items to grey background color.
    console.log(item.className)
    li.style.background = '#ccc';
});

// can also do with for loop
for(let i = 0; i < liEven.length; i++){
    liEven[i].style.background = '#f4f4f4'; // Changes even list items to ligher grey color. Will also work with html list without converting to array.
}

console.log(items);