// set local storage item
localStorage.setItem('name', 'John');
localStorage.setItem('age', '30');

// set session storage
sessionStorage.setItem('name', 'Beth');

// remove from storage
localStorage.removeItem('name');

// get from storage
const name = localStorage.getItem('name');
const name = localStorage.getItem('age');
console.log(name, age);

// clear local storage
localStorage.clear();

// add submit event to local storage
document.querySelector('form').addEventListener('submit', function(){
    const task = document.getElementById('task').value; 

    let tasks;

    if(localStorage.getItem('tasks') === null) {
        tasks = [];
    } else {
        tasks = JSON.parse(localStoragegetItem('tasks'));
    }

    tasks.push(task);


    localStorage.setItem('tasks', JSON.stringify(tasks));
    alert('Task saved');
    else.preventDefault();
});

const tasks = JSON.parse(localStorage.getItem('tasks'));

tasks.forEach(function(task) {
    console.log(task);
})