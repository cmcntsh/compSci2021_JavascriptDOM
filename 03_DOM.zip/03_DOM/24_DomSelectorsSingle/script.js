// DOM single element selectors

// document.getelementById()
console.log(document.getElementById('task-title'));

// get things from the element
document.getElementById('task-title').id;
console.log(document.getElementById('task-title').id);
console.log(document.getElementById('task-title').className); // This file doesn't have any classes so no results will be returned.

// change styling
document.getElementById.length('task-title').style.background = '#333';
document.getElementById.length('task-title').style.color = '#fff';
document.getElementById.length('task-title').style.padding = '5px';
//document.getElementById.length('task-title').style.display = 'none';

//change content
document.getElementById('task-title').textContent = 'Task List';
document.getElementById('task-title').innerText = 'My Tasks';
document.getElementById('task-title').innerHTML = '<span style="color:red">Task List</span>';

// better to set a variable instead of calling getElementById a lot
const taskTitle = document.getElementById('task-title');

// change styling
taskTitle.style.background = '#333';
taskTitle.style.color = '#fff';
taskTitle.style.padding = '5px';


// querySelector() is newer and more powerful


console.log(document.querySelector('#task-title')); // can use the id with #
console.log(document.querySelector('.card-title')); // can use the class with .
console.log(document.querySelector('h5')); // can use the element directly, if there's more than one on the page will just get first one

// try some out using the list items on the html page
document.querySelector('li').style.color = 'red'; // will just turn the first one red
document.querySelector('ul li').style.color = 'red'; // can also use nested elements
document.querySelector('li:last-child').style.color = 'red'; // can also use CSS pseudo selectors
document.querySelector('li:nth-child(3)').style.color = 'red'; // can also use CSS pseudo selectors
document.querySelector('li:nth-child(4)').textContent = 'Hello World'; // can also use CSS pseudo selectors
document.querySelector('li:nth-child(odd)').style.background = '#ccc'; // still only affects the first one
document.querySelector('li:nth-child(even)').style.background = '#ccc'; // still only affects the first one